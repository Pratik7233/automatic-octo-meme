/**
 * 
 */
console.log("Smart Farm Management System Loaded");
