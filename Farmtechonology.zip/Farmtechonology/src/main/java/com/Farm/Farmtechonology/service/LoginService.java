package com.Farm.Farmtechonology.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.Farm.Farmtechonology.model.Login;
import com.Farm.Farmtechonology.repository.LoginRepository;

@Service
public class LoginService {
	
	    @Autowired
	    private LoginRepository farmerRepository;

	    public Login registerFarmer(Login login) {
	        return farmerRepository.save(login);
	    }

	    public Login loginFarmer(String email, String password) {
	        Login login = farmerRepository.findByEmail(email);
	        if (login != null && login.getPassword().equals(password)) {
	            return login;
	        }
	        return null;}}

