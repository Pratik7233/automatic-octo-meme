package com.Farm.Farmtechonology.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.Farm.Farmtechonology.model.Crop;
import com.Farm.Farmtechonology.repository.CropRepository;

import java.util.List;


@Service
public class CropService {
	
	    @Autowired
	    private CropRepository cropRepository;

	    // Fetch all crops
	    public List<Crop> getAllCrops() {
	        return cropRepository.findAll();
	    }

	    // Save a new crop
	    public Crop saveCrop(Crop crop) {
	        return cropRepository.save(crop);
	    }

	    // Find crop by ID
	    public Crop getCropById(Long id) {
	        return cropRepository.findById(id).orElse(null);
	    }

	    // Delete crop by ID
	    public void deleteCrop(Long id) {
	        cropRepository.deleteById(id);}}