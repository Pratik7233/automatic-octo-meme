package com.Farm.Farmtechonology.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.Farm.Farmtechonology.model.User;



public interface UserRepository extends JpaRepository<User, Long> {
	Optional<User> findByUsername(String username);
}