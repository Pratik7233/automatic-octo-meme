package com.Farm.Farmtechonology.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class Crop {
    
   
        @Id
        @GeneratedValue(strategy = GenerationType.IDENTITY)
        private Long id;
        private String name;
        private String season;
        private String type;
        private double price;
		public Long getId() {
			return id;
		}
		public void setId(Long id) {
			this.id = id;
		}
		public String getName() {
			return name;
		}
		public void setName(String name) {
			this.name = name;
		}
		public String getSeason() {
			return season;
		}
		public void setSeason(String season) {
			this.season = season;
		}
		public String getType() {
			return type;
		}
		public void setType(String type) {
			this.type = type;
		}
		public double getPrice() {
			return price;
		}
		public void setPrice(double price) {
			this.price = price;
		}
		@Override
		public String toString() {
			return "Crop [id=" + id + ", name=" + name + ", season=" + season + ", type=" + type + ", price=" + price
					+ "]";
		}
		public Crop(Long id, String name, String season, String type, double price) {
			super();
			this.id = id;
			this.name = name;
			this.season = season;
			this.type = type;
			this.price = price;
		}
		public Crop() {
			super();
			// TODO Auto-generated constructor stub
		}

}