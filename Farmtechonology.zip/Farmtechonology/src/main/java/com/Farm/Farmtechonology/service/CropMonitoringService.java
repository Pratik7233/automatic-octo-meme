package com.Farm.Farmtechonology.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.Farm.Farmtechonology.model.CropMonitoring;
import com.Farm.Farmtechonology.repository.CropMonitoringRepository;

import java.util.List;
import java.util.Optional;

@Service
public class CropMonitoringService {

    @Autowired
    private CropMonitoringRepository cropMonitoringRepository;
       
        // Add or Update Crop Monitoring
        public CropMonitoring saveCropMonitoring(CropMonitoring cropMonitoring) {
            return cropMonitoringRepository.save(cropMonitoring);
        }

        // Get All Crop Monitoring Records
        public List<CropMonitoring> getAllCropMonitoring() {
            return cropMonitoringRepository.findAll();
        }

        // Get Crop Monitoring by ID
        public Optional<CropMonitoring> getCropMonitoringById(Long id) {
            return cropMonitoringRepository.findById(id);
        }

        // Delete Crop Monitoring
        public void deleteCropMonitoring(Long id) {
            cropMonitoringRepository.deleteById(id);}}
