package com.Farm.Farmtechonology.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import com.Farm.Farmtechonology.model.CropMonitoring;
import com.Farm.Farmtechonology.service.CropMonitoringService;



@Controller
@RequestMapping("/cropMonitoring")
public class CropMonitoringController {

    @Autowired
    private CropMonitoringService cropMonitoringService;   
       
        // Display Crop Monitoring Records
        @GetMapping
        public String viewAllCropMonitoring(Model model) {
            model.addAttribute("cropMonitorings", cropMonitoringService.getAllCropMonitoring());
            return "cropMonitoring"; // cropMonitoring.html
        }

        // Add New Crop Monitoring Record
        @PostMapping("/add")
        public String addCropMonitoring(CropMonitoring cropMonitoring) {
            cropMonitoringService.saveCropMonitoring(cropMonitoring);
            return "redirect:/cropMonitoring";
        }

        // Edit Crop Monitoring Record
        @GetMapping("/edit/{id}")
        public String editCropMonitoring(@PathVariable Long id, Model model) {
            CropMonitoring cropMonitoring = cropMonitoringService.getCropMonitoringById(id)
                    .orElseThrow(() -> new IllegalArgumentException("Invalid crop monitoring ID:" + id));
            model.addAttribute("cropMonitoring", cropMonitoring);
            return "editCropMonitoring"; // editCropMonitoring.html
        }

        // Update Crop Monitoring Record
        @PostMapping("/update/{id}")
        public String updateCropMonitoring(@PathVariable Long id, CropMonitoring updatedCropMonitoring) {
            cropMonitoringService.saveCropMonitoring(updatedCropMonitoring);
            return "redirect:/cropMonitoring";
        }

        // Delete Crop Monitoring Record
        @GetMapping("/delete/{id}")
        public String deleteCropMonitoring(@PathVariable Long id) {
            cropMonitoringService.deleteCropMonitoring(id);
            return "redirect:/cropMonitoring";}}
    