package com.Farm.Farmtechonology.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.Farm.Farmtechonology.model.Stock;
import com.Farm.Farmtechonology.repository.StockRepository;

import java.util.List;
import java.util.Optional;

@Service
public class StockService {

    @Autowired
    private StockRepository stockRepository;

        // Add or Update Stock Item
        public Stock saveStock(Stock stock) {
            return stockRepository.save(stock);
        }

        // Get All Stock Items
        public List<Stock> getAllStock() {
            return stockRepository.findAll();
        }

        // Get Stock Item by ID
        public Optional<Stock> getStockById(Long id) {
            return stockRepository.findById(id);
        }

        // Delete Stock Item
        public void deleteStock(Long id) {
            stockRepository.deleteById(id);}}