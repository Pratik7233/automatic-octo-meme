package com.Farm.Farmtechonology.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;


import com.Farm.Farmtechonology.model.Crop;
import com.Farm.Farmtechonology.service.CropService;


@Controller
@RequestMapping("/crops")
public class CropController {
	
	    @Autowired
	    private CropService cropService;

	    // Display list of crops
	    @GetMapping
	    public String listCrops(Model model) {
	        model.addAttribute("crops", cropService.getAllCrops());
	        return "cropManagement";
	    }

	    // Show form for adding new crop
	    @GetMapping("/add")
	    public String showAddForm(Model model) {
	        model.addAttribute("crop", new Crop());
	        return "addCrop";
	    }

	    // Save new crop
	    @PostMapping("/add")
	    public String saveCrop(@ModelAttribute("crop") Crop crop) {
	        cropService.saveCrop(crop);
	        return "redirect:/crop";
	    }

	    // Show form for editing crop
	    @GetMapping("/edit/{id}")
	    public String showEditForm(@PathVariable Long id, Model model) {
	        model.addAttribute("crop", cropService.getCropById(id));
	        return "editCrop";
	    }

	    // Update crop
	    @PostMapping("/edit/{id}")
	    public String updateCrop(@PathVariable Long id, @ModelAttribute("crop") Crop crop) {
	        Crop existingCrop = cropService.getCropById(id);
	        existingCrop.setName(crop.getName());
	        existingCrop.setSeason(crop.getSeason());
	        existingCrop.setType(crop.getType());
	        cropService.saveCrop(existingCrop);
	        return "redirect:/crop";
	    }

	    // Delete crop
	    @GetMapping("/delete/{id}")
	    public String deleteCrop(@PathVariable Long id) {
	        cropService.deleteCrop(id);
	        return "redirect:/crop";}}