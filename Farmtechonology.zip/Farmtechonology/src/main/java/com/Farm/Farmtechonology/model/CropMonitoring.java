package com.Farm.Farmtechonology.model;

import java.util.Date;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class CropMonitoring {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private Long cropId;
    private String date;
    private String growthStage;
    private String healthStatus;
    private String notes;
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public Long getCropId() {
		return cropId;
	}
	public void setCropId(Long cropId) {
		this.cropId = cropId;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public String getGrowthStage() {
		return growthStage;
	}
	public void setGrowthStage(String growthStage) {
		this.growthStage = growthStage;
	}
	public String getHealthStatus() {
		return healthStatus;
	}
	public void setHealthStatus(String healthStatus) {
		this.healthStatus = healthStatus;
	}
	public String getNotes() {
		return notes;
	}
	public void setNotes(String notes) {
		this.notes = notes;
	}
	@Override
	public String toString() {
		return "CropMonitoring [id=" + id + ", cropId=" + cropId + ", date=" + date + ", growthStage=" + growthStage
				+ ", healthStatus=" + healthStatus + ", notes=" + notes + "]";
	}
	public CropMonitoring(Long id, Long cropId, String date, String growthStage, String healthStatus, String notes) {
		super();
		this.id = id;
		this.cropId = cropId;
		this.date = date;
		this.growthStage = growthStage;
		this.healthStatus = healthStatus;
		this.notes = notes;
	}
	public CropMonitoring() {
		super();
		// TODO Auto-generated constructor stub
	}
}
	