package com.Farm.Farmtechonology.controller;

import com.Farm.Farmtechonology.model.User;
import com.Farm.Farmtechonology.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class RegisterController {

    @Autowired
    private UserService farmerService;

    // Show registration page
    @GetMapping("/register")
    public String showRegistrationForm() {
        return "register"; // returns the register.html template
    }

    // Handle registration form submission
    @PostMapping("/register")
    public String registerFarmer(User farmer, Model model) {
        // Save the farmer using the service
        try {
//            farmerService.saveUser(farmer);
            model.addAttribute("message", "Farmer registered successfully! Please login.");
            return "login"; // Redirect to login page
        } catch (Exception e) {
            model.addAttribute("error", "Registration failed! Please try again.");
            return "register"; // Stay on the registration page
        }
    }
}
