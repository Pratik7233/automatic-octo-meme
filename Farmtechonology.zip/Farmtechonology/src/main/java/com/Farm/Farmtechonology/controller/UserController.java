package com.Farm.Farmtechonology.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;

import org.springframework.web.bind.annotation.*;

import com.Farm.Farmtechonology.model.User;
import com.Farm.Farmtechonology.service.UserService;



@Controller
@RequestMapping("/api/users")
public class UserController {

    @Autowired
    private UserService userService;
       
        @PostMapping("/register")
        public ResponseEntity<String> registerUser(@RequestBody User user) {
            if (userService.findByUsername(user.getUsername()).isPresent()) {
                return ResponseEntity.badRequest().body("Username already exists!");
            }
            userService.registerUser(user);
            return ResponseEntity.ok("User registered successfully!");
        }

        @PostMapping("/login")
        public ResponseEntity<String> loginUser(@RequestBody User user) {
            return userService.findByUsername(user.getUsername())
                    .filter(u -> u.getPassword().equals(user.getPassword()))
                    .map(u -> ResponseEntity.ok("Login successful! Role: " + u.getRole()))
                    .orElse(ResponseEntity.badRequest().body("Invalid credentials!"));}}