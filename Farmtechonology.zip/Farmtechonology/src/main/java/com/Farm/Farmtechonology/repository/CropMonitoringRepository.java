package com.Farm.Farmtechonology.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.Farm.Farmtechonology.model.CropMonitoring;

public interface CropMonitoringRepository extends JpaRepository<CropMonitoring, Long> {}