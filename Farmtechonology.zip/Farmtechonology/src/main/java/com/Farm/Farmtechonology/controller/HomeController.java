package com.Farm.Farmtechonology.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.Farm.Farmtechonology.model.CropMonitoring;
import com.Farm.Farmtechonology.model.Stock;
import com.Farm.Farmtechonology.service.CropMonitoringService;
import com.Farm.Farmtechonology.service.StockService;
@Controller
@RequestMapping("/home")
public class HomeController {
	
	    @Autowired
	    private CropMonitoringService cropmoniteringservices;

	    @Autowired
	    private StockService stockService;

	    // Home Page - Display Crops and Stock
	    @GetMapping
	    public String viewHomePage(Model model) {
	        model.addAttribute("crops", cropmoniteringservices.getAllCropMonitoring());
	        model.addAttribute("stocks", stockService.getAllStock());
	        return "home"; // home.html
	    }

	    // Add a new crop
	    @PostMapping("/CropMonitering")
	    public String cropmonitering(CropMonitoring crop) {
	        cropmoniteringservices.saveCropMonitoring(crop);
	        return "redirect:/home";
	    }

	    // Add a new stock item
	    @PostMapping("/addStock")
	    public String addStock(Stock stock) {
	        stockService.saveStock(stock);
	        return "redirect:/home";}}


