package com.Farm.Farmtechonology.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.Farm.Farmtechonology.model.Login;
import com.Farm.Farmtechonology.service.LoginService;

import org.springframework.ui.Model;

@Controller
@RequestMapping("/login")
public class LoginController {

	    @Autowired
	    private LoginService loginService;

	    @GetMapping
	    public String showSignUpForm() {
	        return "login";
	    }

	    @PostMapping("/register")
	    public String registerFarmer(Login login, Model model) {
	        loginService.registerFarmer(login);
	        model.addAttribute("message", "Registration successful!");
	        return "login";
	    }

	    @GetMapping("/login")
	    public String showLoginForm() {
	        return "login";
	    }

	    @PostMapping("/login")
	    public String loginFarmer(@RequestParam String email, @RequestParam String password, Model model) {
	        Login farmer = loginService.loginFarmer(email, password);
	       
	        if (farmer != null) {
	            model.addAttribute("name", farmer.getName());
	            return "dashboard";
	        } else {
	            model.addAttribute("error", "Invalid credentials!");
	            return "login";}}}