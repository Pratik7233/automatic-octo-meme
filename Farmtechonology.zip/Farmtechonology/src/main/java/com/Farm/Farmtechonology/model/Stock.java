package com.Farm.Farmtechonology.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class Stock {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String itemName;  
    private String itemType;      // e.g., "Seed", "Fertilizer", "Machinery"
    private Integer quantity;
    private String description;
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getItemName() {
		return itemName;
	}
	public void setItemName(String itemName) {
		this.itemName = itemName;
	}
	public String getItemType() {
		return itemType;
	}
	public void setItemType(String itemType) {
		this.itemType = itemType;
	}
	public Integer getQuantity() {
		return quantity;
	}
	public void setQuantity(Integer quantity) {
		this.quantity = quantity;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	@Override
	public String toString() {
		return "Stock [id=" + id + ", itemName=" + itemName + ", itemType=" + itemType + ", quantity=" + quantity
				+ ", description=" + description + "]";
	}
	public Stock(Long id, String itemName, String itemType, Integer quantity, String description) {
		super();
		this.id = id;
		this.itemName = itemName;
		this.itemType = itemType;
		this.quantity = quantity;
		this.description = description;
	}
	public Stock() {
		super();
		// TODO Auto-generated constructor stub
	}
}
    
	