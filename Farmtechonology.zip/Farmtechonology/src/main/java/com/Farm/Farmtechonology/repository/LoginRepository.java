package com.Farm.Farmtechonology.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.Farm.Farmtechonology.model.Login;

public interface LoginRepository extends JpaRepository<Login, Long > {
Login findByEmail(String email);
}
