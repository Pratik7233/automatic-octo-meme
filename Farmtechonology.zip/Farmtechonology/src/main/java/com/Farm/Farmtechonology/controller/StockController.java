package com.Farm.Farmtechonology.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import com.Farm.Farmtechonology.model.Stock;
import com.Farm.Farmtechonology.service.StockService;



@Controller
@RequestMapping("/stock")
public class StockController {

    @Autowired
    private StockService stockService;

        // Display All Stock Items
        @GetMapping
        public String viewAllStock(Model model) {
            model.addAttribute("stocks", stockService.getAllStock());
            return "stock"; // stock.html
        }

        // Add New Stock Item
        @PostMapping("/add")
        public String addStock(Stock stock) {
            stockService.saveStock(stock);
            return "redirect:/stock";
        }

        // Edit Stock Item
        @GetMapping("/edit/{id}")
        public String editStock(@PathVariable Long id, Model model) {
            Stock stock = stockService.getStockById(id)
                    .orElseThrow(() -> new IllegalArgumentException("Invalid stock ID:" + id));
            model.addAttribute("stock", stock);
            return "editStock"; // editStock.html
        }

        // Update Stock Item
        @PostMapping("/update/{id}")
        public String updateStock(@PathVariable Long id, Stock updatedStock) {
            stockService.saveStock(updatedStock);
            return "redirect:/stock";
        }

        // Delete Stock Item
        @GetMapping("/delete/{id}")
        public String deleteStock(@PathVariable Long id) {
            stockService.deleteStock(id);
            return "redirect:/stock";}}