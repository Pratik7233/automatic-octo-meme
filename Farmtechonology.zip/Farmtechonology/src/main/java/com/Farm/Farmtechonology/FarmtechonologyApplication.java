package com.Farm.Farmtechonology;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FarmtechonologyApplication {

	public static void main(String[] args) {
		SpringApplication.run(FarmtechonologyApplication.class, args);
	}

}
