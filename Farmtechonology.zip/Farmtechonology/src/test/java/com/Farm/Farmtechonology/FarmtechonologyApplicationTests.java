package com.Farm.Farmtechonology;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FarmtechonologyApplicationTests {

	@Test
	void contextLoads() {
	}

}
